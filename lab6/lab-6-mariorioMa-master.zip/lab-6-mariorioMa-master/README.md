# Lab-6 assignment

Refer to [Lab-6 manual](https://nju-cn-course.gitbook.io/nju-computer-network-lab-manual/lab-6)
